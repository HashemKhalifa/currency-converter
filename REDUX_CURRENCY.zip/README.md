# Plutus Frontend Code Challenge

Welcome to the Plutus Frontend code challenge.
The point of this exercise is to get a better understanding of the way you think and code. We'd like to see how you go about your solution, how you structure the code, what you consider important and what not, etc.

## The Challenge

Create a currency converter calculator, same as google's. The widget has four inputs. The first two are for the sum to be converted. Changing one calculates the converted sum for the other, and changes the top titles accordingly. The other two inputs are currency drop downs, one for each of the first two inputs.
**Important: The currencies in the title must be shown in de_DE locale**

[Here's a live example that converts 100 Euros to dollars.](https://bit.ly/2KQMbo5) The live example might not show the result in the requested locale, as it depends on the locale google determines on your machine.

![Google Example:](./calculator-example.png)

Google's converter also has a graph that shows the conversion over time. **This feature is NOT REQUIRED to implement.**

### Assets
* The currency codes and the currency names can be consumed directly from the consts file: `src/consts/CurrencyCodes.js` or from the redux state in global.currencyCodes. Each currency should have only one occurrence in the currency selector inputs.
* The currency conversion rate should be fetched from the free api: https://free.currencyconverterapi.com/
* This project was created with create-react-app. If you need any additional information please read `Create-React-App-README.me` or lookup `create react app`.


### General instructions
* The current project has the following dependencies already added:
  * react
  * react-dom
  * redux
  * Jest
* Please feel free to add any additional library you think you will need, but please have a good argument why you need it. Also do not feel forced to use any of the existing libraries (save for React).
* You can use any JS edition which is supported by babel. Feel free to change the configuration if you wish to use features which are not supported out of the box in create-react-app.
* To get started:
  * Fork the project.
  * Make sure you have Node >= 6 on your local development machine.
  * run `yarn` to install dependencies or `npm install` if you don't have yarn.
  * Run`yarn start` or `npm start` to run the development server.
  * Run 'yarn test' or 'npm test' to run tests.
* To end the challenge:
  * When you finish the challenge, please create a pull request with your solution, or (if not possible) send us an archive with your solution, or a link to google drive.
* Feel free to lookup any information you need during the execution of the challenge. If you have any questions, or need any clarification, please reach out to us.
* Try to limit the work to no more than a few hours.

### What you should focus on
* Functionality. It needs to work, ideally without bugs.
* UX and performance. Think of the end users, and what makes most sense for them.
* Proper architecture, and decision making. Feel free to design and change anything, but have a clear idea as to why.

Thank you for taking the Plutus Frontend code challenge! We hope to see you as part of our team!

